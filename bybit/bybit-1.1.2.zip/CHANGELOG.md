# Bybit Adapter 1.1.2

- 修复 Bybit `req_timestamp / server_timestamp / recv_window` 时间偏差导致保护性止损监听暂时不可用的问题。
- 服务器时间校准改用请求往返中点估算，降低 VPS 网络延迟对签名时间戳的影响。
- 遇到 Bybit 时间戳错误（含 retCode 10002）时，自动采用响应中的服务器时间重新校准并重新签名重试一次。
- 保护性止损监听改为连续 3 次失败后才显示警告；恢复后自动恢复正常状态。
- 保留现货 / USDT 永续、Live / Testnet / Demo、实时成交、历史同步、杠杆/IM/MM/仓位价值快照与初始保护性止损捕获逻辑。
